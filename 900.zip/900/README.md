# PSFree version 1.5.0b

Lapse Kex ported to 9.00

Very fast and reliable! Around 80% stability rate.

Update: I've added an payload having some process_dtor_handler patches related to aio bugs.. Now all games should work properly.. patches were made by abc for 8.0x and I ported to 9.00. Thx a lot to Sistro and CTN for some explanation on low level coding!!! :)

PSFree is a collection of exploits for the PS4 console. The main focus of the 
repo is for the PS4 but we try to make things portable to PS5.

* Exploits
  * PSFree: src/psfree.mjs
  * Lapse (kernel): src/scripts/lapse.mjs

# COPYRIGHT AND AUTHORS:
AGPL-3.0-or-later (see src/COPYING). This repo belongs to the group
`anonymous`. We refer to anonymous contributors as "anonymous" as well.
# CREDITS:
* anonymous for PS4 firmware kernel dumps
* Check the appropriate files for any **extra** contributors. Unless otherwise
  stated, everything here can also be credited to us.
